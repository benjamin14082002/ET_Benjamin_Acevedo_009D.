import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-edit-event-modal',
  templateUrl: './edit-event-modal.component.html',
  styleUrls: ['./edit-event-modal.component.scss'],
})
export class EditEventModalComponent implements OnInit {

  @Input() evento: any;  // Define the evento property to receive data from the parent component

  constructor(private modalController: ModalController) { }

  ngOnInit() {}

  // Method to close the modal
  closeModal() {
    this.modalController.dismiss();  // Dismiss the modal without returning any data
  }

  // Method to save the changes made to the event
  saveChanges() {
    this.modalController.dismiss(this.evento);  // Dismiss the modal and pass the updated event data back to the parent component
  }
}
