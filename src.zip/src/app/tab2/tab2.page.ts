import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
})
export class Tab2Page implements OnInit {
  evento: any; // Variable para almacenar los datos del evento
  
  usuario:any;
  id:any;
  qrdata:string;
  nombre:any;




  
  constructor(private router: Router,
              private activated:ActivatedRoute,
              private alertcontroller: AlertController) {
                this.activated.queryParams.subscribe(param =>{
                  this.usuario =JSON.parse(param['usuario']);
                })
                this.qrdata='';
                this.nombre =sessionStorage.getItem('username')
              }

  ngOnInit() {
    // Recuperar los datos enviados desde tab1 (si existe)
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras && navigation.extras.state) {
      this.evento = navigation.extras.state['evento'];
    } else {
      console.log('No se recibieron datos del evento.');
    }
  }

  mostrarqr(){
    this.qrdata='';
    this.qrdata = this.usuario.nombre + this.usuario.evento + this.nombre;
    console.log(this.qrdata)
  }
}