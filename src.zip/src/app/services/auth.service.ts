import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IuserNuevoAdmin, IUsersAdmin } from '../interface/UserAdmin';
import { IEvent } from '../interface/UserAdmin';  // Importa la interfaz de eventos
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpclient: HttpClient) { }

  // Método para obtener todos los usuarios
  GetAllUsers(): Observable<IUsersAdmin[]> {
    return this.httpclient.get<IUsersAdmin[]>(`${environment.apiUrl}/usuarios`);
  }

  // Método para obtener un usuario por su nombre de usuario
  GetUserByUsername(usuario: string): Observable<IUsersAdmin> {
    return this.httpclient.get<IUsersAdmin[]>(`${environment.apiUrl}/usuarios?username=${usuario}`).pipe(
      map(users => users[0]) 
    );
  }

  // Método para verificar si el usuario está logueado
  IsLoggedIn(): boolean {
    return sessionStorage.getItem('username') !== null;
  }

  // Método para crear un nuevo usuario
  PostUsuario(newUsuario: IuserNuevoAdmin): Observable<IuserNuevoAdmin> {
    return this.httpclient.post<IuserNuevoAdmin>(`${environment.apiUrl}/usuarios`, newUsuario);
  }

  // Método para obtener un usuario por su nombre de usuario (alternativa)
  getUserByusername(usuario: string): Observable<IUsersAdmin> {
    return this.httpclient.get<IUsersAdmin>(`${environment.apiUrl}/usuarios?username=${usuario}`);
  }

  // Métodos para manejar eventos

  // Obtener todos los eventos
  GetAllEvents(): Observable<IEvent[]> {
    return this.httpclient.get<IEvent[]>(`${environment.apiUrl}/eventos`);
  }

  // Crear un nuevo evento
  PostEvent(newEvent: IEvent): Observable<IEvent> {
    return this.httpclient.post<IEvent>(`${environment.apiUrl}/eventos`, newEvent);
  }

  // Obtener un evento por su ID
  GetEventById(eventId: string): Observable<IEvent> {
    return this.httpclient.get<IEvent>(`${environment.apiUrl}/eventos/${eventId}`);
  }

  // Actualizar un evento
  UpdateEvent(eventId: string, updatedEvent: IEvent): Observable<IEvent> {
    return this.httpclient.put<IEvent>(`${environment.apiUrl}/eventos/${eventId}`, updatedEvent);
  }
}
