import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { Users } from '../interface/users';

@Component({
  selector: 'app-perfil',
  templateUrl: './tab3.page.html',
  styleUrls: ['./tab3.page.scss'],
})
export class PerfilPage implements OnInit {
  isProfileTab = false;
  profileImage: string | ArrayBuffer | null = null; // Almacena la foto de perfil
  user: Users | null = null;

  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.isProfileTab = event.urlAfterRedirects === '/tabs/tab3';
      }
    });

    this.loadUserData();
  }

  loadUserData() {
    const username = sessionStorage.getItem('username');
    if (username) {
      this.authService.GetUserByUsername(username).subscribe(
        (data) => {
          console.log('Datos recibidos:', data);
          this.user = data;
        },
        (error) => {
          console.error('Error al cargar los datos del usuario', error);
        }
      );
    } else {
      console.error('No hay usuario autenticado');
    }
  }

  logout() {
    sessionStorage.clear(); // Limpia los datos de sesión
    this.router.navigate(['/login']); // Redirige al usuario a la página de inicio de sesión
    console.log('Usuario desconectado');
  }

  onFileSelected(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        this.profileImage = reader.result; // Actualiza la imagen de perfil con la nueva
        console.log('Foto de perfil actualizada');
      };
      reader.readAsDataURL(file);
    }
  }
}
