import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { IUsersAdmin } from '../interface/UserAdmin';

@Component({
  selector: 'app-perfil',
  templateUrl: './tab3.page.html',
  styleUrls: ['./tab3.page.scss'],
})
export class PerfilPage implements OnInit {
  isProfileTab = false;
  user:IUsersAdmin |  null=null;

  constructor(private router: Router,
              private authService:AuthService
  ) { }

  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.isProfileTab = event.urlAfterRedirects === '/tabs/tab3';
      }
    });

    this.loadUserData();
  }

  loadUserData() {
    const username = sessionStorage.getItem('username');
    if (username) {
      this.authService.GetUserByUsername(username).subscribe(
        (data) => {
          console.log('Datos recibidos:', data);
          this.user = data;
        },
        (error) => {
          console.error('Error al cargar los datos del usuario', error);
        }
      );
    } else {
      console.error('No hay usuario autenticado');
    }
  }


  logout() {
    sessionStorage.clear(); // Limpia los datos de sesión
    this.router.navigate(['/login']); // Redirige al usuario a la página de inicio de sesión
    console.log('Usuario desconectado');
  }
}
