import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service'
import { AlertController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-password-recovery',
  templateUrl: './password-recovery.page.html',
  styleUrls: ['./password-recovery.page.scss'],
})
export class PasswordRecoveryPage {
  email: string = '';
  isLoading: boolean = false;

  constructor(
    private authService: AuthService,
    private alertCtrl: AlertController,
    private loadingCtrl: LoadingController
  ) {}

  async onSubmit() {
    if (!this.email) {
      const alert = await this.alertCtrl.create({
        header: 'Error',
        message: 'Por favor, ingresa un correo válido.',
        buttons: ['OK'],
      });
      await alert.present();
      return;
    }

    this.isLoading = true;

    this.authService.solicitarRecuperacion(this.email).subscribe(
      async (response) => {
        this.isLoading = false;
        const alert = await this.alertCtrl.create({
          header: 'Éxito',
          message: 'Se ha enviado un correo con las instrucciones de recuperación.',
          buttons: ['OK'],
        });
        await alert.present();
      },
      async (error) => {
        this.isLoading = false;
        const alert = await this.alertCtrl.create({
          header: 'Error',
          message:
            'Hubo un problema al procesar la solicitud. Por favor, intenta nuevamente más tarde.',
          buttons: ['OK'],
        });
        await alert.present();
        console.error('Error en la recuperación de contraseña:', error);
      }
    );
  }
}
