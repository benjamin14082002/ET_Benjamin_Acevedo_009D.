import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { IuserNuevoAdmin } from '../interface/UserAdmin';
import { NavController } from '@ionic/angular';  // Importar NavController

@Component({
  selector: 'app-registrate',
  templateUrl: './registrate.page.html',
  styleUrls: ['./registrate.page.scss'],
})
export class RegistratePage implements OnInit {

  registroForm: FormGroup;

  nuevoUsuario: IuserNuevoAdmin = {
    username: "",
    email: "",
    password: "",
    isactive: false
  }

  userdata: any;

  constructor(
    private authservice: AuthService,
    private alertController: AlertController,
    private router: Router,
    private fBuilder: FormBuilder,
    private navCtrl: NavController  // Inyectar NavController
  ) {
    this.registroForm = this.fBuilder.group({
      'username': new FormControl("", [Validators.required, Validators.minLength(6)]),
      'email': new FormControl("", [Validators.required, Validators.email]),
      'password': new FormControl("", [Validators.required, Validators.pattern(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/)]),
    });
  }

  CrearUsuario() {
    if (this.registroForm.valid) {
      this.authservice.getUserByusername(this.registroForm.value.username).subscribe(resp => {
        this.userdata = resp;
        if (this.userdata.length > 0) {
          this.registroForm.reset();
          this.errorDuplicidad();
        } else {
          this.nuevoUsuario.username = this.registroForm.value.username;
          this.nuevoUsuario.password = this.registroForm.value.password;
          this.nuevoUsuario.email = this.registroForm.value.email;
          this.nuevoUsuario.isactive = true;
          this.authservice.PostUsuario(this.nuevoUsuario).subscribe();
          this.registroForm.reset();
          this.mostrarMensaje();
          this.router.navigateByUrl('/login');
        }
      });
    }
  }

  // Función para regresar
  regresar() {
    this.navCtrl.back();  // Regresa a la página anterior
  }

  async mostrarMensaje() {
    const alerta = await this.alertController.create({
      header: 'Usuario Creado',
      message: 'Bienvenido a Talleres Duoc Uc ' + this.nuevoUsuario.username,
      buttons: ['OK']
    });
    alerta.present();
  }

  async errorDuplicidad() {
    const alerta = await this.alertController.create({
      header: 'Error',
      message: 'Usted ' + this.nuevoUsuario.username + ' Ya está Registrado :D',
      buttons: ['OK']
    });
    alerta.present();
  }

  ngOnInit() { }
}
