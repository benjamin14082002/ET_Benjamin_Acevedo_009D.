import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router'; // Importa Router

@Component({
  selector: 'app-password',
  templateUrl: './password.page.html',
  styleUrls: ['./password.page.scss'],
})
export class PasswordPage implements OnInit {

  // Definir los botones de la alerta
  alertButtons = [
    {
      text: 'Confirmar',
      role: 'confirm',
      handler: () => {
        // Redirige al usuario a la página de login
        this.router.navigate(['/login']);
      }
    }
  ];

  constructor(
    private alertController: AlertController,
    private router: Router // Inyectar Router
  ) { }

  ngOnInit() {}

  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Contraseña',
      message: 'Cambiada Correctamente',
      buttons: this.alertButtons
    });

    await alert.present();
  }
}
