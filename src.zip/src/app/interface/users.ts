export interface Users{
    id:string;
    username:string;
    email:string;
    password:string;
    isactive:boolean;
}

export interface userNuevo{
    username:string;
    email:string;
    password:string;
    isactive:boolean;
}