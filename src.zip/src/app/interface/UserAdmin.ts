export interface IUsersAdmin{
    id:string;
    username:string;
    email:string;
    password:string;
    isactive:boolean;
}

export interface IuserNuevoAdmin{
    username:string;
    email:string;
    password:string;
    isactive:boolean;
}


export interface IEvent {
    id: string;
    name: string;
    description: string;
    date: Date;  // Formato de fecha que utilizarás
    location: string;
}  