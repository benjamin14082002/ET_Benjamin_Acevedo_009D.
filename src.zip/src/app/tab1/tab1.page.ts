import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tab1',
  templateUrl: './tab1.page.html',
  styleUrls: ['./tab1.page.scss'],
})
export class Tab1Page implements OnInit {

  // Lista de eventos
  eventos = [
    {
      nombre: 'Taller De Programacion',
      descripcion: 'Duoc Uc sede Maipú Te invita a inscribirte a este taller donde tendras tus primeros pasos con la programacion aprendiendo lo basico',
      fecha: '12-11-2024',
      hora: '10:00',
      ubicacion: 'Duoc Uc Sede Maipú',
      imagen: 'assets/prog.jpg'
    },
    {
      nombre: 'Taller De Redes',
      descripcion: 'Duoc Uc sede Maipú Te invita a inscribirte a este taller donde tendras tus primeros pasos en Redes aprenderas todo lo basico que nesecitas',
      fecha: '20-11-2024',
      hora: '15:00',
      ubicacion: 'Duoc Uc Sede Maipú',
      imagen: 'assets/redes.jpg'
    }
  ];

  // Lista de imágenes para el carrusel
  images: string[] = [
    'assets/Duoc.jpeg',
    'assets/Programacion.jpg',
    'assets/Redes2.jpg'
  ];

  constructor(private router: Router) {}

  // Método para redirigir a la página de inscripción y pasar los datos del evento
  inscripcion(evento: any) {
    this.router.navigate(['/tabs/tab2'], { state: { evento } });
  }

  ngOnInit() {}
}
