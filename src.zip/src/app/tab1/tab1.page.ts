import { Component } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { EditEventModalComponent } from '../edit-event-modal/edit-event-modal.component';

@Component({
  selector: 'app-tab1',
  templateUrl: './tab1.page.html',
  styleUrls: ['./tab1.page.scss'],
})
export class Tab1Page {
  eventos = [
    {
      nombre: 'Evento 1',
      descripcion: 'Descripción del evento 1',
      fecha: '2024-09-15',
      hora: '10:00',
      ubicacion: 'Ubicación del evento 1',
    },
    {
      nombre: 'Evento 2',
      descripcion: 'Descripción del evento 2',
      fecha: '2024-09-20',
      hora: '15:00',
      ubicacion: 'Ubicación del evento 2',
    },
  ];

  constructor(private modalController: ModalController, private toastController: ToastController) {}

  // Método para abrir el modal de edición de evento
  async modifyEvent(evento: any) {
    const modal = await this.modalController.create({
      component: EditEventModalComponent,
      componentProps: { evento },
    });

    modal.onDidDismiss().then((result) => {
      if (result.data) {
        // Actualiza el evento con los nuevos datos
        const index = this.eventos.findIndex((e) => e === evento);
        if (index !== -1) {
          this.eventos[index] = result.data;
        }
        this.showToast('Evento modificado con éxito');
      }
    });

    return await modal.present();
  }

  // Método para eliminar un evento
  async deleteEvent(evento: any) {
    this.eventos = this.eventos.filter((e) => e !== evento);
    this.showToast(`El evento "${evento.nombre}" ha sido eliminado.`);
  }

  // Método para mostrar un mensaje de Toast
  async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
    });
    await toast.present();
  }

  // Método para agregar un nuevo evento
  addNewEvent() {
    const nuevoEvento = {
      nombre: 'Nuevo Evento',
      descripcion: 'Descripción del nuevo evento',
      fecha: '2024-12-25',
      hora: '18:00',
      ubicacion: 'Ubicación del nuevo evento',
    };
    this.eventos.push(nuevoEvento);
    this.showToast('Nuevo evento agregado');
  }
}
