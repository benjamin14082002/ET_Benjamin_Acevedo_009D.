import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Users, userNuevo } from '../interface/users';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private httpclient: HttpClient) {}

  GetAllUsers(): Observable<Users[]> {
    return this.httpclient.get<Users[]>(`${environment.apiUrl}/usuarios`);
  }

  GetUserByUsername(usuario: string): Observable<Users> {
    return this.httpclient.get<Users[]>(`${environment.apiUrl}/usuarios?username=${usuario}`).pipe(
      map(users => users[0]) 
    );
  }

  IsLoggedIn(): boolean {
    return sessionStorage.getItem('username') !== null;
  }

  PostUsuario(newUsuario: userNuevo): Observable<userNuevo> {
    return this.httpclient.post<userNuevo>(`${environment.apiUrl}/usuarios`, newUsuario);
  }

  getUserByusername(usuario: string): Observable<Users> {
    return this.httpclient.get<Users>(`${environment.apiUrl}/usuarios?username=${usuario}`);
  }

  // Solicita la recuperación de contraseña
  solicitarRecuperacion(email: string): Observable<any> {
    return this.httpclient.post(`${environment.apiUrl}/usuarios`, { email });
  }

  // Restablece la contraseña del usuario
  resetPassword(token: string, newPassword: string): Observable<any> {
    return this.httpclient.post(`${environment.apiUrl}/reset-password`, { token, newPassword });
  }
}
