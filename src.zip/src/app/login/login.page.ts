import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  userdata: any;

  usuario = {
    id: 0,
    username: "",
    email: "",
    password: "",
    isactive: false
  };

  loginForm: FormGroup;

  constructor(
    private authservice: AuthService,
    private router: Router,
    private toast: ToastController,
    private alertcontroller: AlertController,
    private builder: FormBuilder
  ) {
    this.loginForm = this.builder.group({
      'username': new FormControl("", [Validators.required, Validators.minLength(6)]),
      'password': new FormControl("", [Validators.required, Validators.minLength(8)])
    });
  }

  login() {
    if (!this.loginForm.valid) {
      return;
    }

    const username = this.loginForm.value.username;
    const password = this.loginForm.value.password;

    this.authservice.GetUserByUsername(username).subscribe(resp => {
      this.userdata = resp;
      console.log(this, this.userdata);

      // Verifica si no se encontró el usuario o si no tiene las propiedades necesarias
  if (!this.userdata || !this.userdata.username || !this.userdata.id) {
    this.loginForm.reset();
    this.UsuarioNoExiste();
    return;
  }

      this.usuario = {
        id: this.userdata.id,
        username: this.userdata.username,
        password: this.userdata.password,
        email: this.userdata.email,
        isactive: this.userdata.isactive
      };

      if (this.usuario.password !== password) {
        this.loginForm.reset();
        this.ErrorUsuario();
        return;
      }

      this.IniciarSesion(this.usuario);
    });
  }

  private IniciarSesion(usuario: any) {
    sessionStorage.setItem('username', usuario.username);
    sessionStorage.setItem('password', usuario.password);
    sessionStorage.setItem('ingresado', 'true');
    this.showToast('Sesion Iniciada');
    this.router.navigate(['/tabs/tab1']);
  }

  async showToast(msg: any) {
    const toast = await this.toast.create({
      message: msg,
      duration: 3000
    });
    toast.present();
  }

  async UsuarioInactivo() {
    const alerta = await this.alertcontroller.create({
      header: 'Usuario Inactivo',
      message: 'Contactar a admin@admin,cl',
      buttons: ['OK']
    });
    alerta.present();
  }

  async ErrorUsuario() {
    const alerta = await this.alertcontroller.create({
      header: 'Error',
      message: 'Revise Sus Credenciales',
      buttons: ['OK']
    });
    alerta.present();
  }

  async UsuarioNoExiste() {
    const alerta = await this.alertcontroller.create({
      header: 'Usuario No Existe',
      message: 'Debe Registrarse',
      buttons: ['OK']
    });
    alerta.present();
  }

  registrate() {
    this.router.navigate(['/registrate']);
  }

  password() {
    this.router.navigate(['/password-recovery']);
  }

  ngOnInit() {}
}
