export const environment = {
  production: true,
  apiUrl:'https://cloneadmin.onrender.com'
};
